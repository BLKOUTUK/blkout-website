# Extension Icons

This directory should contain the following icon files:
- icon16.png (16x16 pixels)
- icon32.png (32x32 pixels)  
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

These icons represent the BLKOUT brand and should be professionally designed.
For testing purposes, placeholder icons can be used.