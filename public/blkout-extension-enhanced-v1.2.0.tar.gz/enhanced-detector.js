// Enhanced BLKOUT Content Detection Script with IVOR AI Integration
class EnhancedBlkoutDetector {
  constructor() {
    this.API_BASE = 'https://blkout-website.vercel.app/api';
    this.IVOR_BASE = 'https://ivor-api-gateway.vercel.app/api';
    
    // Enhanced platform selectors
    this.platformConfig = {
      eventbrite: {
        title: ['h1[data-automation="event-title"]', '.event-title h1'],
        description: ['[data-automation="event-description"]', '.event-description'],
        date: ['[data-automation="event-date-time"]', '.event-dates'],
        location: ['[data-automation="event-location"]', '.event-venue-details']
      },
      facebook: {
        title: ['[data-testid="event-title"]', 'h1', '[role="heading"]'],
        description: ['[data-testid="event-description"]', '[data-testid="event-permalink-text"]'],
        date: ['[data-testid="event-time"]', '.event-date'],
        location: ['[data-testid="event-location"]']
      },
      meetup: {
        title: ['h1', '[data-testid="event-title"]'],
        description: ['[data-testid="description"]', '.event-description'],
        date: ['[data-testid="event-date"]', '.event-time-display'],
        location: ['[data-testid="venue-name"]', '.venue-info']
      },
      guardian: {
        title: ['h1[data-gu-name="headline"]', '.content__headline', 'h1'],
        standfirst: ['[data-gu-name="standfirst"]'],
        content: ['[data-gu-name="body"]', '.content__article-body'],
        author: ['[data-gu-name="author"]', '.byline']
      },
      bbc: {
        title: ['h1[data-testid="headline"]', '[data-component="headline"]', 'h1'],
        content: ['[data-component="text-block"]', '[data-testid="article-body"]', 'main'],
        author: ['.byline', '[data-testid="author-name"]']
      },
      independent: {
        title: ['h1'],
        content: ['.sc-1tw5ko3-3', 'article', '.article-content'],
        author: ['[data-testid="author-name"]', '.byline']
      },
      twitter: {
        tweet: ['[data-testid="tweetText"]', '.tweet-text'],
        author: ['[data-testid="User-Name"]', '.username'],
        timestamp: ['[data-testid="Time"]', 'time']
      }
    };
    
    this.contentQualityThresholds = {
      minTitleLength: 10,
      minContentLength: 100,
      minEventContentLength: 50,
      maxTitleLength: 200,
      maxDescriptionLength: 1000
    };
    
    this.init();
  }
  
  async init() {
    await this.detectContent();
    this.setupAIEnhancement();
  }
  
  async detectContent() {
    const url = window.location.href;
    const hostname = window.location.hostname;
    
    let detectedContent = null;
    
    // Platform-specific detection with improved accuracy
    if (hostname.includes('eventbrite')) {
      detectedContent = await this.detectPlatformContent('eventbrite', 'event');
    } else if (hostname.includes('facebook')) {
      detectedContent = await this.detectPlatformContent('facebook', 'event');
    } else if (hostname.includes('meetup')) {
      detectedContent = await this.detectPlatformContent('meetup', 'event');
    } else if (hostname.includes('theguardian.com')) {
      detectedContent = await this.detectPlatformContent('guardian', 'article');
    } else if (hostname.includes('bbc.co.uk') || hostname.includes('bbc.com')) {
      detectedContent = await this.detectPlatformContent('bbc', 'article');
    } else if (hostname.includes('independent.co.uk')) {
      detectedContent = await this.detectPlatformContent('independent', 'article');
    } else if (hostname.includes('twitter.com') || hostname.includes('x.com')) {
      detectedContent = await this.detectPlatformContent('twitter', 'article');
    } else {
      detectedContent = await this.detectGenericContent();
    }
    
    if (detectedContent) {
      // Enhance with IVOR AI analysis
      detectedContent = await this.enhanceWithIVOR(detectedContent);
      
      this.foundContent = detectedContent;
      this.highlightContent();
      this.addEnhancedFloatingButton();
    }
  }
  
  async detectPlatformContent(platform, defaultType) {
    const config = this.platformConfig[platform];
    if (!config) return null;
    
    const extractText = (selectors) => {
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          return element.textContent?.trim();
        }
      }
      return null;
    };
    
    const title = extractText(config.title);
    if (!title || title.length < this.contentQualityThresholds.minTitleLength) {
      return null;
    }
    
    const content = {
      type: defaultType,
      platform,
      title: this.sanitizeText(title),
      url: window.location.href,
      extractedAt: new Date().toISOString()
    };
    
    // Extract platform-specific fields
    if (config.description) {
      const description = extractText(config.description);
      if (description) {
        content.description = this.sanitizeText(description, this.contentQualityThresholds.maxDescriptionLength);
      }
    }
    
    if (config.content) {
      const bodyContent = extractText(config.content);
      if (bodyContent) {
        content.description = content.description || this.sanitizeText(bodyContent, this.contentQualityThresholds.maxDescriptionLength);
      }
    }
    
    if (config.standfirst) {
      const standfirst = extractText(config.standfirst);
      if (standfirst) {
        content.standfirst = this.sanitizeText(standfirst);
      }
    }
    
    if (config.author) {
      const author = extractText(config.author);
      if (author) {
        content.author = this.sanitizeText(author);
      }
    }
    
    if (config.date) {
      const date = extractText(config.date);
      if (date) {
        content.dateTime = date;
        content.parsedDate = this.parseDate(date);
      }
    }
    
    if (config.location) {
      const location = extractText(config.location);
      if (location) {
        content.location = this.sanitizeText(location);
      }
    }
    
    // Special handling for Twitter/X
    if (platform === 'twitter') {
      const tweet = extractText(config.tweet);
      const author = extractText(config.author);
      
      if (tweet && tweet.length > 20) {
        content.title = tweet.length > 100 ? tweet.substring(0, 100) + '...' : tweet;
        content.description = tweet;
        content.author = author || 'Twitter User';
        content.type = 'article';
      } else {
        return null;
      }
    }
    
    // Validate content quality
    if (!this.validateContentQuality(content)) {
      return null;
    }
    
    return content;
  }
  
  async detectGenericContent() {
    const title = document.querySelector('h1')?.textContent?.trim() || 
                 document.title?.trim();
    
    const content = document.querySelector('article')?.textContent?.trim() ||
                   document.querySelector('main')?.textContent?.trim() ||
                   document.querySelector('.content')?.textContent?.trim() ||
                   document.body?.textContent?.trim();
    
    if (!title || !content) return null;
    
    // Determine content type using enhanced keywords
    const eventKeywords = [
      'event', 'workshop', 'conference', 'meetup', 'gathering', 
      'protest', 'march', 'rally', 'celebration', 'ceremony', 
      'forum', 'seminar', 'webinar', 'panel', 'discussion',
      'fundraiser', 'gala', 'exhibition', 'screening', 'performance'
    ];
    
    const combinedText = (title + ' ' + content.substring(0, 500)).toLowerCase();
    const isEvent = eventKeywords.some(keyword => combinedText.includes(keyword));
    
    const detectedContent = {
      type: isEvent ? 'event' : 'article',
      platform: 'generic',
      title: this.sanitizeText(title),
      description: this.sanitizeText(content, this.contentQualityThresholds.maxDescriptionLength),
      url: window.location.href,
      extractedAt: new Date().toISOString(),
      confidence: this.calculateConfidence(title, content, isEvent)
    };
    
    if (!this.validateContentQuality(detectedContent)) {
      return null;
    }
    
    return detectedContent;
  }
  
  async enhanceWithIVOR(content) {
    try {
      // Use IVOR AI to analyze and enhance the detected content
      const enhancement = await this.callIVORAI({
        action: 'analyze_content',
        content: {
          title: content.title,
          description: content.description,
          platform: content.platform,
          type: content.type
        }
      });
      
      if (enhancement && enhancement.success) {
        content.ivorAnalysis = enhancement.analysis;
        content.suggestedCategory = enhancement.category;
        content.relevanceScore = enhancement.relevance_score;
        content.communityTags = enhancement.suggested_tags;
        content.aiEnhanced = true;
      }
    } catch (error) {
      console.warn('IVOR AI enhancement failed:', error);
      content.aiEnhanced = false;
    }
    
    return content;
  }
  
  async callIVORAI(data) {
    const response = await fetch(`${this.IVOR_BASE}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      timeout: 5000
    });
    
    if (!response.ok) {
      throw new Error(`IVOR API error: ${response.status}`);
    }
    
    return await response.json();
  }
  
  sanitizeText(text, maxLength = null) {
    if (!text) return '';
    
    // Clean up text
    let cleaned = text
      .replace(/\s+/g, ' ') // Normalize whitespace
      .replace(/[^\w\s\-.,!?;:()"']/g, '') // Remove special chars
      .trim();
    
    if (maxLength && cleaned.length > maxLength) {
      cleaned = cleaned.substring(0, maxLength - 3) + '...';
    }
    
    return cleaned;
  }
  
  parseDate(dateString) {
    try {
      const date = new Date(dateString);
      return date.toISOString().split('T')[0];
    } catch {
      return null;
    }
  }
  
  validateContentQuality(content) {
    if (!content.title || content.title.length < this.contentQualityThresholds.minTitleLength) {
      return false;
    }
    
    if (content.type === 'event') {
      return content.description && content.description.length >= this.contentQualityThresholds.minEventContentLength;
    } else {
      return content.description && content.description.length >= this.contentQualityThresholds.minContentLength;
    }
  }
  
  calculateConfidence(title, content, isEvent) {
    let confidence = 0.5; // Base confidence
    
    // Title quality
    if (title.length > 20 && title.length < 100) confidence += 0.2;
    
    // Content length
    if (content.length > 500) confidence += 0.1;
    if (content.length > 1000) confidence += 0.1;
    
    // Platform indicators
    if (isEvent && content.toLowerCase().includes('date')) confidence += 0.1;
    if (content.toLowerCase().includes('community')) confidence += 0.1;
    
    return Math.min(confidence, 1.0);
  }
  
  highlightContent() {
    if (!this.foundContent) return;
    
    const style = document.createElement('style');
    style.textContent = `
      .blkout-detected {
        outline: 2px dashed #4CAF50 !important;
        outline-offset: 2px !important;
        position: relative !important;
      }
      .blkout-detected::after {
        content: "✓ BLKOUT Detected";
        position: absolute;
        top: -25px;
        right: -2px;
        background: #4CAF50;
        color: white;
        padding: 2px 8px;
        font-size: 10px;
        border-radius: 3px;
        z-index: 9998;
      }
      .blkout-floating-btn {
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        z-index: 9999 !important;
        background: linear-gradient(135deg, #000 0%, #333 100%) !important;
        color: white !important;
        border: none !important;
        padding: 12px 18px !important;
        border-radius: 25px !important;
        cursor: pointer !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3) !important;
        transition: all 0.3s ease !important;
        min-width: 160px !important;
        text-align: center !important;
      }
      .blkout-floating-btn:hover {
        background: linear-gradient(135deg, #333 0%, #555 100%) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 25px rgba(0,0,0,0.4) !important;
      }
      .blkout-ai-badge {
        display: inline-block;
        background: #9C27B0;
        color: white;
        font-size: 8px;
        padding: 2px 4px;
        border-radius: 10px;
        margin-left: 5px;
        vertical-align: super;
      }
    `;
    document.head.appendChild(style);
  }
  
  addEnhancedFloatingButton() {
    if (!this.foundContent) return;
    
    const button = document.createElement('button');
    button.className = 'blkout-floating-btn';
    
    let buttonText = `🚀 Submit ${this.foundContent.type} to BLKOUT`;
    if (this.foundContent.aiEnhanced) {
      buttonText += '<span class="blkout-ai-badge">AI</span>';
    }
    
    button.innerHTML = buttonText;
    button.title = `Detected: ${this.foundContent.title}`;
    
    if (this.foundContent.relevanceScore) {
      button.title += `\nRelevance: ${Math.round(this.foundContent.relevanceScore * 100)}%`;
    }
    
    button.addEventListener('click', () => {
      this.showEnhancedSubmissionForm();
    });
    
    document.body.appendChild(button);
    
    // Add subtle animation
    setTimeout(() => {
      button.style.animation = 'blkout-pulse 2s infinite';
    }, 1000);
    
    // Add pulse animation
    const pulseStyle = document.createElement('style');
    pulseStyle.textContent = `
      @keyframes blkout-pulse {
        0% { box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        50% { box-shadow: 0 4px 20px rgba(76, 175, 80, 0.5); }
        100% { box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
      }
    `;
    document.head.appendChild(pulseStyle);
  }
  
  showEnhancedSubmissionForm() {
    const event = new CustomEvent('blkout-show-enhanced-submission', {
      detail: this.foundContent
    });
    document.dispatchEvent(event);
  }
  
  setupAIEnhancement() {
    // Listen for form enhancement requests
    document.addEventListener('blkout-enhance-form', async (event) => {
      const formData = event.detail;
      try {
        const enhancement = await this.callIVORAI({
          action: 'enhance_submission',
          data: formData
        });
        
        if (enhancement && enhancement.success) {
          const enhancedEvent = new CustomEvent('blkout-form-enhanced', {
            detail: enhancement
          });
          document.dispatchEvent(enhancedEvent);
        }
      } catch (error) {
        console.error('Form enhancement failed:', error);
      }
    });
  }
}

// Enhanced initialization with error handling
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    try {
      new EnhancedBlkoutDetector();
    } catch (error) {
      console.error('BLKOUT Extension: Failed to initialize detector', error);
    }
  });
} else {
  try {
    new EnhancedBlkoutDetector();
  } catch (error) {
    console.error('BLKOUT Extension: Failed to initialize detector', error);
  }
}