// Enhanced BLKOUT Form Injector with IVOR AI Integration
class EnhancedBlkoutFormInjector {
  constructor() {
    this.API_BASE = 'https://blkout-website.vercel.app/api';
    this.IVOR_BASE = 'https://ivor-api-gateway.vercel.app/api';
    this.currentContent = null;
    this.formVisible = false;
    
    this.setupEventListeners();
  }
  
  setupEventListeners() {
    // Listen for enhanced submission form requests
    document.addEventListener('blkout-show-enhanced-submission', (event) => {
      this.currentContent = event.detail;
      this.showEnhancedSubmissionForm();
    });
    
    // Listen for AI enhancement requests
    document.addEventListener('blkout-enhance-form', (event) => {
      this.enhanceFormWithAI(event.detail);
    });
    
    // Listen for form enhancement results
    document.addEventListener('blkout-form-enhanced', (event) => {
      this.applyAIEnhancements(event.detail);
    });
  }
  
  showEnhancedSubmissionForm() {
    if (this.formVisible || !this.currentContent) return;
    
    const form = this.createEnhancedForm();
    this.injectForm(form);
    this.formVisible = true;
  }
  
  createEnhancedForm() {
    const formHtml = `
      <div id="blkout-enhanced-form" class="blkout-form-overlay">
        <div class="blkout-form-container">
          <div class="blkout-form-header">
            <h3>🚀 Submit to BLKOUT Community Platform</h3>
            ${this.currentContent.aiEnhanced ? '<span class="ai-badge">✨ AI Enhanced</span>' : ''}
            <button class="close-btn" onclick="this.parentElement.parentElement.parentElement.remove(); window.blkoutFormInjector.formVisible = false;">&times;</button>
          </div>
          
          <div class="blkout-form-body">
            ${this.currentContent.relevanceScore ? `
              <div class="relevance-indicator">
                <div class="relevance-bar">
                  <div class="relevance-fill" style="width: ${Math.round(this.currentContent.relevanceScore * 100)}%"></div>
                </div>
                <span>Community Relevance: ${Math.round(this.currentContent.relevanceScore * 100)}%</span>
              </div>
            ` : ''}
            
            <form id="blkout-enhanced-submission">
              <div class="form-group">
                <label>Type:</label>
                <select name="type" id="enhanced-type" onchange="window.blkoutFormInjector.toggleFormFields(this.value)">
                  <option value="${this.currentContent.type}" selected>${this.currentContent.type.charAt(0).toUpperCase() + this.currentContent.type.slice(1)}</option>
                  <option value="${this.currentContent.type === 'event' ? 'article' : 'event'}">${this.currentContent.type === 'event' ? 'Article' : 'Event'}</option>
                </select>
              </div>
              
              <div class="form-group">
                <label>Title:</label>
                <input type="text" name="title" value="${this.escapeHtml(this.currentContent.title)}" required>
              </div>
              
              <div class="form-group">
                <label>Description:</label>
                <textarea name="description" rows="4" placeholder="Add more details...">${this.escapeHtml(this.currentContent.description || '')}</textarea>
                ${this.currentContent.aiEnhanced ? '<button type="button" class="ai-enhance-btn" onclick="window.blkoutFormInjector.enhanceDescription()">✨ AI Enhance</button>' : ''}
              </div>
              
              ${this.currentContent.ivorAnalysis ? `
                <div class="ai-analysis">
                  <h4>🤖 AI Analysis</h4>
                  <p>${this.escapeHtml(this.currentContent.ivorAnalysis)}</p>
                  ${this.currentContent.communityTags ? `
                    <div class="suggested-tags">
                      <strong>Suggested Tags:</strong>
                      ${this.currentContent.communityTags.map(tag => `<span class="tag">${this.escapeHtml(tag)}</span>`).join('')}
                    </div>
                  ` : ''}
                </div>
              ` : ''}
              
              <div id="event-fields" style="display: ${this.currentContent.type === 'event' ? 'block' : 'none'}">
                <div class="form-group">
                  <label>Date:</label>
                  <input type="date" name="date" value="${this.currentContent.parsedDate || new Date().toISOString().split('T')[0]}">
                </div>
                
                <div class="form-group">
                  <label>Time:</label>
                  <input type="time" name="time" value="18:00">
                </div>
                
                <div class="form-group">
                  <label>Location:</label>
                  <input type="text" name="location" value="${this.escapeHtml(this.currentContent.location || '')}" placeholder="Event location">
                </div>
              </div>
              
              <div id="article-fields" style="display: ${this.currentContent.type === 'article' ? 'block' : 'none'}">
                <div class="form-group">
                  <label>Category:</label>
                  <select name="category">
                    <option value="${this.currentContent.suggestedCategory || 'community-response'}" selected>${this.formatCategory(this.currentContent.suggestedCategory || 'community-response')}</option>
                    <option value="original">Original</option>
                    <option value="curated">Curated</option>
                    <option value="community-response">Community Response</option>
                  </select>
                </div>
                
                ${this.currentContent.author ? `
                  <div class="form-group">
                    <label>Original Author:</label>
                    <input type="text" name="original_author" value="${this.escapeHtml(this.currentContent.author)}" readonly>
                  </div>
                ` : ''}
              </div>
              
              <div class="form-actions">
                <button type="submit" class="submit-btn">
                  🚀 Submit to BLKOUT
                  ${this.currentContent.aiEnhanced ? '<span class="ai-indicator">AI</span>' : ''}
                </button>
                <button type="button" class="cancel-btn" onclick="this.parentElement.parentElement.parentElement.parentElement.parentElement.remove(); window.blkoutFormInjector.formVisible = false;">Cancel</button>
              </div>
            </form>
            
            <div id="submission-status"></div>
          </div>
        </div>
      </div>
    `;
    
    return formHtml;
  }
  
  injectForm(formHtml) {
    // Remove existing form if present
    const existing = document.getElementById('blkout-enhanced-form');
    if (existing) existing.remove();
    
    // Create form element
    const formDiv = document.createElement('div');
    formDiv.innerHTML = formHtml;
    
    // Add styles
    this.injectStyles();
    
    // Add to page
    document.body.appendChild(formDiv.firstElementChild);
    
    // Setup form submission
    document.getElementById('blkout-enhanced-submission').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleEnhancedSubmission(e.target);
    });
  }
  
  injectStyles() {
    if (document.getElementById('blkout-form-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'blkout-form-styles';
    style.textContent = `
      .blkout-form-overlay {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: rgba(0, 0, 0, 0.8) !important;
        z-index: 999999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      }
      
      .blkout-form-container {
        background: white !important;
        border-radius: 12px !important;
        max-width: 500px !important;
        width: 90% !important;
        max-height: 90vh !important;
        overflow-y: auto !important;
        box-shadow: 0 20px 40px rgba(0,0,0,0.3) !important;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
      }
      
      .blkout-form-header {
        background: linear-gradient(135deg, #000 0%, #333 100%) !important;
        color: white !important;
        padding: 20px !important;
        border-radius: 12px 12px 0 0 !important;
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
      }
      
      .blkout-form-header h3 {
        margin: 0 !important;
        font-size: 18px !important;
        font-weight: 600 !important;
      }
      
      .ai-badge {
        background: #9C27B0 !important;
        color: white !important;
        padding: 4px 8px !important;
        border-radius: 12px !important;
        font-size: 12px !important;
        font-weight: 600 !important;
      }
      
      .close-btn {
        background: none !important;
        border: none !important;
        color: white !important;
        font-size: 24px !important;
        cursor: pointer !important;
        padding: 0 !important;
        width: 30px !important;
        height: 30px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      }
      
      .blkout-form-body {
        padding: 20px !important;
      }
      
      .relevance-indicator {
        margin-bottom: 20px !important;
      }
      
      .relevance-bar {
        width: 100% !important;
        height: 8px !important;
        background: #f0f0f0 !important;
        border-radius: 4px !important;
        overflow: hidden !important;
        margin-bottom: 5px !important;
      }
      
      .relevance-fill {
        height: 100% !important;
        background: linear-gradient(90deg, #FF6B35 0%, #4CAF50 50%, #2196F3 100%) !important;
        transition: width 0.3s ease !important;
      }
      
      .form-group {
        margin-bottom: 15px !important;
      }
      
      .form-group label {
        display: block !important;
        margin-bottom: 5px !important;
        font-weight: 600 !important;
        color: #333 !important;
      }
      
      .form-group input, .form-group select, .form-group textarea {
        width: 100% !important;
        padding: 10px !important;
        border: 2px solid #e0e0e0 !important;
        border-radius: 6px !important;
        font-size: 14px !important;
        box-sizing: border-box !important;
        transition: border-color 0.2s !important;
      }
      
      .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
        outline: none !important;
        border-color: #000 !important;
      }
      
      .ai-enhance-btn {
        background: #9C27B0 !important;
        color: white !important;
        border: none !important;
        padding: 6px 12px !important;
        border-radius: 4px !important;
        font-size: 12px !important;
        cursor: pointer !important;
        margin-top: 5px !important;
      }
      
      .ai-analysis {
        background: #f8f9ff !important;
        border: 1px solid #e3e8ff !important;
        border-radius: 8px !important;
        padding: 15px !important;
        margin: 15px 0 !important;
      }
      
      .ai-analysis h4 {
        margin: 0 0 10px 0 !important;
        color: #4C51BF !important;
        font-size: 14px !important;
      }
      
      .suggested-tags {
        margin-top: 10px !important;
      }
      
      .tag {
        display: inline-block !important;
        background: #e0e7ff !important;
        color: #4C51BF !important;
        padding: 3px 8px !important;
        border-radius: 12px !important;
        font-size: 12px !important;
        margin: 2px 4px 2px 0 !important;
      }
      
      .form-actions {
        display: flex !important;
        gap: 10px !important;
        margin-top: 20px !important;
      }
      
      .submit-btn {
        flex: 1 !important;
        background: linear-gradient(135deg, #000 0%, #333 100%) !important;
        color: white !important;
        border: none !important;
        padding: 12px 20px !important;
        border-radius: 6px !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        transition: all 0.2s !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
      }
      
      .submit-btn:hover {
        background: linear-gradient(135deg, #333 0%, #555 100%) !important;
        transform: translateY(-1px) !important;
      }
      
      .ai-indicator {
        background: #9C27B0 !important;
        padding: 2px 6px !important;
        border-radius: 8px !important;
        font-size: 10px !important;
      }
      
      .cancel-btn {
        background: #f0f0f0 !important;
        color: #666 !important;
        border: none !important;
        padding: 12px 20px !important;
        border-radius: 6px !important;
        cursor: pointer !important;
      }
      
      #submission-status {
        margin-top: 15px !important;
        padding: 10px !important;
        border-radius: 6px !important;
        text-align: center !important;
      }
      
      .status-success {
        background: #d4edda !important;
        color: #155724 !important;
        border: 1px solid #c3e6cb !important;
      }
      
      .status-error {
        background: #f8d7da !important;
        color: #721c24 !important;
        border: 1px solid #f5c6cb !important;
      }
      
      .status-loading {
        background: #d1ecf1 !important;
        color: #0c5460 !important;
        border: 1px solid #b6d4db !important;
      }
    `;
    
    document.head.appendChild(style);
  }
  
  toggleFormFields(type) {
    const eventFields = document.getElementById('event-fields');
    const articleFields = document.getElementById('article-fields');
    
    if (type === 'event') {
      eventFields.style.display = 'block';
      articleFields.style.display = 'none';
    } else {
      eventFields.style.display = 'none';
      articleFields.style.display = 'block';
    }
  }
  
  async enhanceDescription() {
    const descriptionField = document.querySelector('[name="description"]');
    const currentDescription = descriptionField.value;
    
    // Trigger AI enhancement
    const enhanceEvent = new CustomEvent('blkout-enhance-form', {
      detail: {
        action: 'enhance_description',
        currentDescription,
        contentType: this.currentContent.type,
        platform: this.currentContent.platform
      }
    });
    document.dispatchEvent(enhanceEvent);
  }
  
  applyAIEnhancements(enhancement) {
    if (enhancement.enhanced_description) {
      const descriptionField = document.querySelector('[name="description"]');
      descriptionField.value = enhancement.enhanced_description;
    }
    
    if (enhancement.suggested_category) {
      const categoryField = document.querySelector('[name="category"]');
      if (categoryField) categoryField.value = enhancement.suggested_category;
    }
  }
  
  async handleEnhancedSubmission(form) {
    const formData = new FormData(form);
    const type = formData.get('type');
    
    const submitData = {
      title: formData.get('title'),
      description: formData.get('description'),
      sourceUrl: window.location.href,
      detectedAt: new Date().toISOString(),
      submittedVia: 'chrome-extension-enhanced',
      platform: this.currentContent.platform,
      aiEnhanced: this.currentContent.aiEnhanced || false,
      relevanceScore: this.currentContent.relevanceScore
    };
    
    if (this.currentContent.ivorAnalysis) {
      submitData.aiAnalysis = this.currentContent.ivorAnalysis;
      submitData.suggestedTags = this.currentContent.communityTags;
    }
    
    if (type === 'event') {
      submitData.date = formData.get('date');
      submitData.time = formData.get('time') || '18:00';
      submitData.duration = 120;
      submitData.organizer = 'Community Submitted';
      submitData.category = 'Community';
      submitData.location = {
        type: 'physical',
        address: formData.get('location') || 'TBD'
      };
      submitData.capacity = 50;
      submitData.featured = false;
      submitData.status = 'draft';
      submitData.tags = ['community-submitted', 'ai-enhanced'];
    } else {
      submitData.category = formData.get('category') || 'community-response';
      submitData.priority = 'medium';
      submitData.type = 'community-response';
      submitData.author = formData.get('original_author') || 'Community Submitted';
      submitData.status = 'draft';
      submitData.tags = ['community-submitted'];
      if (this.currentContent.aiEnhanced) {
        submitData.tags.push('ai-enhanced');
      }
      submitData.featured = false;
    }
    
    this.showStatus('🚀 Submitting to BLKOUT...', 'loading');
    
    try {
      const endpoint = type === 'event' ? '/events' : '/articles';
      const response = await fetch(this.API_BASE + endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(submitData)
      });
      
      const responseData = await response.json();
      
      if (response.ok && responseData.success) {
        this.showStatus('✅ Successfully submitted to BLKOUT! Our community moderators will review it shortly.', 'success');
        setTimeout(() => {
          document.getElementById('blkout-enhanced-form').remove();
          this.formVisible = false;
        }, 3000);
      } else {
        throw new Error(responseData.message || responseData.error || 'Unknown error');
      }
    } catch (error) {
      console.error('Enhanced submission error:', error);
      this.showStatus(`❌ Submission failed: ${error.message}. Please try again or visit BLKOUT website directly.`, 'error');
    }
  }
  
  showStatus(message, type) {
    const statusEl = document.getElementById('submission-status');
    statusEl.innerHTML = message;
    statusEl.className = `status-${type}`;
  }
  
  formatCategory(category) {
    return category.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  }
  
  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Initialize enhanced form injector
window.blkoutFormInjector = new EnhancedBlkoutFormInjector();